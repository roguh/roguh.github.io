DEFAULT EXTENSIONS
==================
This folder contains the default extension packages that must be
distributed with Game Maker. 

To get these files here, run the Maker program in the parent
folder and install/deinstall the correct packages. They will
then be placed in this folder.

When creating the distribution, the files in this folder
(except for this readme file) must be copied to the correct
extensions folder in the Distribution\Files folder.